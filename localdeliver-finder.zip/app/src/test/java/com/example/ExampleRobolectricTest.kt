package com.example

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.example.data.model.DeliveryPlatform
import com.example.data.model.PinZoneTier
import com.example.data.repository.DeliveryService
import com.example.data.repository.PinCodeRepository
import com.example.data.repository.ProductRepository
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [34])
class ExampleRobolectricTest {

    @Test
    fun `read string from context`() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val appName = context.getString(R.string.app_name)
        assertEquals("LocalDeliver Finder", appName)
    }

    @Test
    fun `test pin code resolution and tier classification`() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val repo = PinCodeRepository(context)

        // Urban / Metro
        val delhi = repo.resolvePinCode("110001")
        assertEquals(PinZoneTier.METRO, delhi.tier)

        // Semi-Urban
        val chhapra = repo.resolvePinCode("841301")
        assertEquals(PinZoneTier.SEMI_URBAN, chhapra.tier)

        // Remote / Rural
        val leh = repo.resolvePinCode("194101")
        assertEquals(PinZoneTier.RURAL, leh.tier)
    }

    @Test
    fun `test deliverability strict filtering by pin tier`() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val repo = PinCodeRepository(context)
        val product = ProductRepository.PRODUCTS.first()

        // In Delhi (Metro): Blinkit and Zepto must be serviceable
        val delhi = repo.resolvePinCode("110001")
        val delhiResults = DeliveryService.evaluateProductDeliverability(product, delhi)
        val delhiBlinkit = delhiResults.first { it.platform == DeliveryPlatform.BLINKIT }
        assertTrue("Blinkit must be serviceable in metro PIN 110001", delhiBlinkit.isServiceable)

        // In Chhapra (Semi-Urban): Blinkit and Zepto must NOT be serviceable
        val chhapra = repo.resolvePinCode("841301")
        val chhapraResults = DeliveryService.evaluateProductDeliverability(product, chhapra)
        val chhapraBlinkit = chhapraResults.first { it.platform == DeliveryPlatform.BLINKIT }
        assertFalse("Blinkit must be marked not serviceable in semi-urban PIN 841301", chhapraBlinkit.isServiceable)

        // Meesho must be serviceable across both
        val meeshoMetro = delhiResults.first { it.platform == DeliveryPlatform.MEESHO }
        val meeshoSemi = chhapraResults.first { it.platform == DeliveryPlatform.MEESHO }
        assertTrue("Meesho must deliver to metro", meeshoMetro.isServiceable)
        assertTrue("Meesho must deliver to semi-urban", meeshoSemi.isServiceable)

        // Local Kirana must always be available
        val kirana = chhapraResults.first { it.platform == DeliveryPlatform.LOCAL_KIRANA }
        assertTrue("Local Kirana must be available", kirana.isServiceable)
    }

    @Test
    fun `test theme modes available`() {
        val modes = com.example.ui.theme.ThemeMode.values()
        assertTrue(modes.contains(com.example.ui.theme.ThemeMode.SYSTEM))
        assertTrue(modes.contains(com.example.ui.theme.ThemeMode.LIGHT))
        assertTrue(modes.contains(com.example.ui.theme.ThemeMode.DARK))
    }
}
