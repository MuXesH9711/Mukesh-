package com.example.ui.viewmodel

import android.app.Application
import android.location.Geocoder
import android.location.Location
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.model.DeliveryPlatform
import com.example.data.model.KiranaStore
import com.example.data.model.PinCodeInfo
import com.example.data.model.PinZoneTier
import com.example.data.model.PlatformCategory
import com.example.data.model.PlatformDeliveryResult
import com.example.data.model.ProductItem
import com.example.data.model.SortOption
import com.example.data.repository.DeliveryService
import com.example.data.repository.PinCodeRepository
import com.example.data.repository.ProductRepository
import com.example.ui.theme.ThemeMode
import com.google.android.gms.location.LocationServices
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.util.Locale

class DeliveryViewModel(application: Application) : AndroidViewModel(application) {

    private val pinCodeRepository = PinCodeRepository(application)
    private val prefs = application.getSharedPreferences("localdeliver_prefs", android.content.Context.MODE_PRIVATE)

    private val _themeMode = MutableStateFlow(
        try {
            ThemeMode.valueOf(prefs.getString("theme_mode", ThemeMode.SYSTEM.name) ?: ThemeMode.SYSTEM.name)
        } catch (e: Exception) {
            ThemeMode.SYSTEM
        }
    )
    val themeMode: StateFlow<ThemeMode> = _themeMode.asStateFlow()

    private val _dynamicColor = MutableStateFlow(
        prefs.getBoolean("dynamic_color", true)
    )
    val dynamicColor: StateFlow<Boolean> = _dynamicColor.asStateFlow()

    fun setThemeMode(mode: ThemeMode) {
        _themeMode.value = mode
        prefs.edit().putString("theme_mode", mode.name).apply()
    }

    fun toggleThemeMode() {
        val next = when (_themeMode.value) {
            ThemeMode.LIGHT -> ThemeMode.DARK
            ThemeMode.DARK -> ThemeMode.SYSTEM
            ThemeMode.SYSTEM -> ThemeMode.LIGHT
        }
        setThemeMode(next)
    }

    fun setDynamicColor(enabled: Boolean) {
        _dynamicColor.value = enabled
        prefs.edit().putBoolean("dynamic_color", enabled).apply()
    }

    private val _currentPinCode = MutableStateFlow(PinCodeRepository.DEFAULT_PIN)
    val currentPinCode: StateFlow<String> = _currentPinCode.asStateFlow()

    private val _currentPinInfo = MutableStateFlow(pinCodeRepository.resolvePinCode(PinCodeRepository.DEFAULT_PIN))
    val currentPinInfo: StateFlow<PinCodeInfo> = _currentPinInfo.asStateFlow()

    val recentPinCodes: StateFlow<List<String>> = pinCodeRepository.recentPinCodes

    private val _searchQuery = MutableStateFlow("")
    val searchQuery: StateFlow<String> = _searchQuery.asStateFlow()

    private val _selectedCategory = MutableStateFlow("All Essentials")
    val selectedCategory: StateFlow<String> = _selectedCategory.asStateFlow()

    private val _selectedSort = MutableStateFlow(SortOption.FASTEST_DELIVERY)
    val selectedSort: StateFlow<SortOption> = _selectedSort.asStateFlow()

    private val _filterDeliverableOnly = MutableStateFlow(false)
    val filterDeliverableOnly: StateFlow<Boolean> = _filterDeliverableOnly.asStateFlow()

    private val _filterCodOnly = MutableStateFlow(false)
    val filterCodOnly: StateFlow<Boolean> = _filterCodOnly.asStateFlow()

    private val _filterPlatformCategory = MutableStateFlow<PlatformCategory?>(null)
    val filterPlatformCategory: StateFlow<PlatformCategory?> = _filterPlatformCategory.asStateFlow()

    private val _selectedProduct = MutableStateFlow(ProductRepository.PRODUCTS.first())
    val selectedProduct: StateFlow<ProductItem> = _selectedProduct.asStateFlow()

    private val _isGpsDetecting = MutableStateFlow(false)
    val isGpsDetecting: StateFlow<Boolean> = _isGpsDetecting.asStateFlow()

    private val _gpsMessage = MutableStateFlow<String?>(null)
    val gpsMessage: StateFlow<String?> = _gpsMessage.asStateFlow()

    private val _selectedKiranaForOrder = MutableStateFlow<KiranaStore?>(null)
    val selectedKiranaForOrder: StateFlow<KiranaStore?> = _selectedKiranaForOrder.asStateFlow()

    // Matching products list
    val filteredProducts: StateFlow<List<ProductItem>> = combine(
        _searchQuery,
        _selectedCategory
    ) { query, category ->
        ProductRepository.searchProducts(query, category)
    }.stateIn(
        viewModelScope,
        SharingStarted.WhileSubscribed(5000),
        ProductRepository.PRODUCTS
    )

    // Platform evaluation for current selected product & pin code
    val platformDeliveryResults: StateFlow<List<PlatformDeliveryResult>> = combine(
        _selectedProduct,
        _currentPinInfo,
        _selectedSort,
        _filterCodOnly,
        _filterPlatformCategory
    ) { product, pinInfo, sort, codOnly, platformCat ->
        var list = DeliveryService.evaluateProductDeliverability(product, pinInfo)

        if (codOnly) {
            list = list.filter { it.isCodAvailable }
        }

        if (platformCat != null) {
            list = list.filter { it.platform.category == platformCat }
        }

        when (sort) {
            SortOption.FASTEST_DELIVERY -> list.sortedWith(
                compareByDescending<PlatformDeliveryResult> { it.isServiceable }
                    .thenBy { it.deliveryDays }
                    .thenBy { it.price }
            )
            SortOption.LOWEST_PRICE -> list.sortedWith(
                compareByDescending<PlatformDeliveryResult> { it.isServiceable }
                    .thenBy { it.price }
                    .thenBy { it.deliveryDays }
            )
            SortOption.PLATFORM_NAME -> list.sortedBy { it.platform.platformName }
        }
    }.stateIn(
        viewModelScope,
        SharingStarted.WhileSubscribed(5000),
        emptyList()
    )

    // Cross-platform Stock Alert
    val stockAlertInfo: StateFlow<DeliveryService.StockAlertInfo?> = combine(
        _selectedProduct,
        _currentPinInfo,
        platformDeliveryResults
    ) { product, pinInfo, results ->
        DeliveryService.findCrossPlatformStockAlert(product, pinInfo, results)
    }.stateIn(
        viewModelScope,
        SharingStarted.WhileSubscribed(5000),
        null
    )

    // Nearby Kiranas
    val nearbyKiranaStores: StateFlow<List<KiranaStore>> = _currentPinInfo.combine(
        _selectedProduct
    ) { pinInfo, _ ->
        DeliveryService.getNearbyKiranaStores(pinInfo)
    }.stateIn(
        viewModelScope,
        SharingStarted.WhileSubscribed(5000),
        DeliveryService.getNearbyKiranaStores(_currentPinInfo.value)
    )

    fun setPinCode(pin: String) {
        val cleanPin = pin.filter { it.isDigit() }.take(6)
        _currentPinCode.value = cleanPin
        if (cleanPin.length == 6) {
            val info = pinCodeRepository.resolvePinCode(cleanPin)
            _currentPinInfo.value = info
            pinCodeRepository.saveRecentPinCode(cleanPin)
            _gpsMessage.value = "Active PIN: ${info.pinCode} (${info.localityName}, ${info.state})"
        }
    }

    fun onSearchQueryChanged(query: String) {
        _searchQuery.value = query
        val matches = ProductRepository.searchProducts(query, _selectedCategory.value)
        if (matches.isNotEmpty() && !matches.contains(_selectedProduct.value)) {
            _selectedProduct.value = matches.first()
        }
    }

    fun onCategorySelected(category: String) {
        _selectedCategory.value = category
        val matches = ProductRepository.searchProducts(_searchQuery.value, category)
        if (matches.isNotEmpty() && !matches.contains(_selectedProduct.value)) {
            _selectedProduct.value = matches.first()
        }
    }

    fun selectProduct(product: ProductItem) {
        _selectedProduct.value = product
    }

    fun setSortOption(sort: SortOption) {
        _selectedSort.value = sort
    }

    fun toggleDeliverableOnly() {
        _filterDeliverableOnly.value = !_filterDeliverableOnly.value
    }

    fun toggleCodOnly() {
        _filterCodOnly.value = !_filterCodOnly.value
    }

    fun setPlatformCategory(cat: PlatformCategory?) {
        _filterPlatformCategory.value = if (_filterPlatformCategory.value == cat) null else cat
    }

    fun openKiranaOrderSheet(store: KiranaStore?) {
        _selectedKiranaForOrder.value = store
    }

    fun clearGpsMessage() {
        _gpsMessage.value = null
    }

    /**
     * Attempts real GPS Geolocation detection, falling back gracefully to curated Indian cities.
     */
    fun detectLocationFromGps() {
        _isGpsDetecting.value = true
        _gpsMessage.value = "Detecting GPS location..."

        viewModelScope.launch {
            try {
                val fusedClient = LocationServices.getFusedLocationProviderClient(getApplication<Application>())
                fusedClient.lastLocation.addOnSuccessListener { location: Location? ->
                    viewModelScope.launch {
                        if (location != null) {
                            val detectedPin = resolveLocationToPin(location)
                            if (detectedPin != null) {
                                setPinCode(detectedPin)
                                _gpsMessage.value = "📍 Auto-detected GPS PIN: $detectedPin"
                            } else {
                                // Default fallback to Bengaluru tech hub if geocoding coordinates are mock
                                val fallbackPin = "560001"
                                setPinCode(fallbackPin)
                                _gpsMessage.value = "📍 Detected Location: Bengaluru ($fallbackPin)"
                            }
                        } else {
                            // Emulator / mock fallback: set to Delhi Central
                            val fallbackPin = "110001"
                            setPinCode(fallbackPin)
                            _gpsMessage.value = "📍 GPS location set to Connaught Place, New Delhi ($fallbackPin)"
                        }
                        _isGpsDetecting.value = false
                    }
                }.addOnFailureListener {
                    // Location permission denied or provider off
                    val fallbackPin = "110001"
                    setPinCode(fallbackPin)
                    _gpsMessage.value = "📍 Defaulted to New Delhi ($fallbackPin). You can enter any 6-digit PIN."
                    _isGpsDetecting.value = false
                }
            } catch (e: SecurityException) {
                // Permission not granted
                _gpsMessage.value = "Location permission needed. Please select or enter PIN manually."
                _isGpsDetecting.value = false
            } catch (e: Exception) {
                _gpsMessage.value = "Could not read GPS. Please enter PIN manually."
                _isGpsDetecting.value = false
            }
        }
    }

    private suspend fun resolveLocationToPin(location: Location): String? = withContext(Dispatchers.IO) {
        try {
            val geocoder = Geocoder(getApplication(), Locale("en", "IN"))
            val addresses = geocoder.getFromLocation(location.latitude, location.longitude, 1)
            val postalCode = addresses?.firstOrNull()?.postalCode
            if (!postalCode.isNullOrBlank() && postalCode.length == 6 && postalCode.all { it.isDigit() }) {
                postalCode
            } else {
                null
            }
        } catch (e: Exception) {
            null
        }
    }
}
