package com.example.ui.theme

import androidx.compose.ui.graphics.Color

val TealPrimary = Color(0xFF0F766E)
val TealPrimaryContainer = Color(0xFFCCFBF1)
val TealOnPrimaryContainer = Color(0xFF115E59)

val OrangeDelivery = Color(0xFFEA580C)
val OrangeDeliveryContainer = Color(0xFFFFEDD5)
val OrangeOnDeliveryContainer = Color(0xFF9A3412)

val BluePAN = Color(0xFF1D4ED8)
val BluePANContainer = Color(0xFFDBEAFE)

val SuccessGreen = Color(0xFF15803D)
val SuccessGreenContainer = Color(0xFFDCFCE7)

val ErrorRed = Color(0xFFDC2626)
val ErrorRedContainer = Color(0xFFFEE2E2)

val Gray50 = Color(0xFFF8FAFC)
val Gray100 = Color(0xFFF1F5F9)
val Gray200 = Color(0xFFE2E8F0)
val Gray400 = Color(0xFF94A3B8)
val Gray600 = Color(0xFF475569)
val Gray800 = Color(0xFF1E293B)
val Gray900 = Color(0xFF0F172A)
