package com.example.ui.components

import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.ElectricBolt
import androidx.compose.material.icons.filled.FilterList
import androidx.compose.material.icons.filled.LocalShipping
import androidx.compose.material.icons.filled.Payments
import androidx.compose.material.icons.filled.Sort
import androidx.compose.material.icons.filled.Storefront
import androidx.compose.material3.AssistChip
import androidx.compose.material3.AssistChipDefaults
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.PlatformCategory
import com.example.data.model.SortOption

@Composable
fun FilterSortRow(
    selectedSort: SortOption,
    onSortSelected: (SortOption) -> Unit,
    deliverableOnly: Boolean,
    onToggleDeliverableOnly: () -> Unit,
    codOnly: Boolean,
    onToggleCodOnly: () -> Unit,
    selectedCategory: PlatformCategory?,
    onCategorySelected: (PlatformCategory?) -> Unit,
    modifier: Modifier = Modifier
) {
    var sortMenuExpanded by remember { mutableStateOf(false) }

    Column(
        modifier = modifier
            .fillMaxWidth()
            .padding(vertical = 4.dp)
    ) {
        // First Row: Sort & Fast filters
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .horizontalScroll(rememberScrollState())
                .padding(horizontal = 16.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            // Sort Dropdown
            Box {
                AssistChip(
                    onClick = { sortMenuExpanded = true },
                    label = {
                        Text(
                            text = selectedSort.title,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.SemiBold
                        )
                    },
                    leadingIcon = {
                        Icon(
                            imageVector = Icons.Default.Sort,
                            contentDescription = "Sort",
                            modifier = Modifier.size(16.dp)
                        )
                    },
                    colors = AssistChipDefaults.assistChipColors(
                        containerColor = MaterialTheme.colorScheme.surfaceVariant
                    ),
                    modifier = Modifier
                        .height(34.dp)
                        .testTag("sort_filter_button")
                )

                DropdownMenu(
                    expanded = sortMenuExpanded,
                    onDismissRequest = { sortMenuExpanded = false }
                ) {
                    SortOption.values().forEach { option ->
                        DropdownMenuItem(
                            text = {
                                Text(
                                    text = option.title,
                                    fontWeight = if (selectedSort == option) FontWeight.Bold else FontWeight.Normal,
                                    color = if (selectedSort == option) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurface
                                )
                            },
                            onClick = {
                                onSortSelected(option)
                                sortMenuExpanded = false
                            },
                            trailingIcon = {
                                if (selectedSort == option) {
                                    Icon(
                                        imageVector = Icons.Default.Check,
                                        contentDescription = "Selected",
                                        tint = MaterialTheme.colorScheme.primary
                                    )
                                }
                            }
                        )
                    }
                }
            }

            // Deliverable to PIN only
            FilterChip(
                selected = deliverableOnly,
                onClick = onToggleDeliverableOnly,
                label = { Text("Deliverable to PIN only", fontSize = 12.sp) },
                leadingIcon = {
                    if (deliverableOnly) {
                        Icon(Icons.Default.Check, contentDescription = null, modifier = Modifier.size(16.dp))
                    }
                },
                colors = FilterChipDefaults.filterChipColors(
                    selectedContainerColor = MaterialTheme.colorScheme.primaryContainer,
                    selectedLabelColor = MaterialTheme.colorScheme.onPrimaryContainer
                ),
                modifier = Modifier
                    .height(34.dp)
                    .testTag("filter_deliverable_only")
            )

            // COD Available Only
            FilterChip(
                selected = codOnly,
                onClick = onToggleCodOnly,
                label = { Text("Cash on Delivery (COD)", fontSize = 12.sp) },
                leadingIcon = {
                    Icon(Icons.Default.Payments, contentDescription = null, modifier = Modifier.size(16.dp))
                },
                colors = FilterChipDefaults.filterChipColors(
                    selectedContainerColor = Color(0xFFDCFCE7),
                    selectedLabelColor = Color(0xFF15803D)
                ),
                modifier = Modifier
                    .height(34.dp)
                    .testTag("filter_cod_only")
            )
        }

        Spacer(modifier = Modifier.height(4.dp))

        // Second Row: Platform Category Pills
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .horizontalScroll(rememberScrollState())
                .padding(horizontal = 16.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            // All Platforms
            FilterChip(
                selected = selectedCategory == null,
                onClick = { onCategorySelected(null) },
                label = { Text("All Platforms", fontSize = 11.5.sp) },
                modifier = Modifier.height(30.dp)
            )

            // PAN-India
            FilterChip(
                selected = selectedCategory == PlatformCategory.PAN_INDIA,
                onClick = { onCategorySelected(PlatformCategory.PAN_INDIA) },
                label = { Text("PAN-India & Bharat", fontSize = 11.5.sp) },
                leadingIcon = {
                    Icon(Icons.Default.LocalShipping, contentDescription = null, modifier = Modifier.size(14.dp))
                },
                modifier = Modifier.height(30.dp)
            )

            // Quick Commerce
            FilterChip(
                selected = selectedCategory == PlatformCategory.QUICK_COMMERCE,
                onClick = { onCategorySelected(PlatformCategory.QUICK_COMMERCE) },
                label = { Text("Quick Commerce (10-30m)", fontSize = 11.5.sp) },
                leadingIcon = {
                    Icon(Icons.Default.ElectricBolt, contentDescription = null, modifier = Modifier.size(14.dp))
                },
                modifier = Modifier.height(30.dp)
            )

            // Local Kirana
            FilterChip(
                selected = selectedCategory == PlatformCategory.LOCAL_KIRANA,
                onClick = { onCategorySelected(PlatformCategory.LOCAL_KIRANA) },
                label = { Text("Kirana Direct", fontSize = 11.5.sp) },
                leadingIcon = {
                    Icon(Icons.Default.Storefront, contentDescription = null, modifier = Modifier.size(14.dp))
                },
                modifier = Modifier.height(30.dp)
            )
        }
    }
}
