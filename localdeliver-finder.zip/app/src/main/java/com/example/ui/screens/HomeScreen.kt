package com.example.ui.screens

import android.Manifest
import android.content.Context
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Clear
import androidx.compose.material.icons.filled.LocalShipping
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalSoftwareKeyboardController
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.data.model.DeliveryPlatform
import com.example.data.model.ProductItem
import com.example.data.repository.PinCodeRepository
import com.example.data.repository.ProductRepository
import com.example.ui.components.FilterSortRow
import com.example.ui.components.LocalKiranaSheet
import com.example.ui.components.LocationPinBar
import com.example.ui.components.PinCodeSelectorSheet
import com.example.ui.components.ProductResultCard
import com.example.ui.components.StockAlertBanner
import com.example.ui.components.ThemeSettingsDialog
import com.example.ui.components.UnserviceablePlatformsCard
import com.example.ui.viewmodel.DeliveryViewModel
import com.example.util.DeepLinkHelper

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HomeScreen(
    viewModel: DeliveryViewModel,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val keyboardController = LocalSoftwareKeyboardController.current

    val currentPinCode by viewModel.currentPinCode.collectAsStateWithLifecycle()
    val currentPinInfo by viewModel.currentPinInfo.collectAsStateWithLifecycle()
    val recentPinCodes by viewModel.recentPinCodes.collectAsStateWithLifecycle()

    val searchQuery by viewModel.searchQuery.collectAsStateWithLifecycle()
    val selectedCategory by viewModel.selectedCategory.collectAsStateWithLifecycle()
    val selectedSort by viewModel.selectedSort.collectAsStateWithLifecycle()
    val filterDeliverableOnly by viewModel.filterDeliverableOnly.collectAsStateWithLifecycle()
    val filterCodOnly by viewModel.filterCodOnly.collectAsStateWithLifecycle()
    val filterPlatformCategory by viewModel.filterPlatformCategory.collectAsStateWithLifecycle()

    val filteredProducts by viewModel.filteredProducts.collectAsStateWithLifecycle()
    val selectedProduct by viewModel.selectedProduct.collectAsStateWithLifecycle()
    val platformDeliveryResults by viewModel.platformDeliveryResults.collectAsStateWithLifecycle()
    val stockAlertInfo by viewModel.stockAlertInfo.collectAsStateWithLifecycle()
    val nearbyKiranas by viewModel.nearbyKiranaStores.collectAsStateWithLifecycle()
    val selectedKiranaForOrder by viewModel.selectedKiranaForOrder.collectAsStateWithLifecycle()

    val isGpsDetecting by viewModel.isGpsDetecting.collectAsStateWithLifecycle()
    val gpsMessage by viewModel.gpsMessage.collectAsStateWithLifecycle()

    val themeMode by viewModel.themeMode.collectAsStateWithLifecycle()
    val dynamicColor by viewModel.dynamicColor.collectAsStateWithLifecycle()
    var showThemeDialog by remember { mutableStateOf(false) }

    // Bottom sheet state for PIN code editor
    var showPinSheet by remember { mutableStateOf(false) }
    val pinSheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)

    // Bottom sheet state for Kirana order
    var showKiranaSheet by remember { mutableStateOf(false) }
    val kiranaSheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)

    // Permission launcher for Location
    val locationPermissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestMultiplePermissions()
    ) { permissions ->
        val granted = permissions[Manifest.permission.ACCESS_FINE_LOCATION] == true ||
                permissions[Manifest.permission.ACCESS_COARSE_LOCATION] == true
        if (granted) {
            viewModel.detectLocationFromGps()
        } else {
            Toast.makeText(context, "Location permission denied. Enter PIN manually.", Toast.LENGTH_SHORT).show()
        }
    }

    val serviceableResults = remember(platformDeliveryResults) {
        platformDeliveryResults.filter { it.isServiceable }
    }
    val unserviceableResults = remember(platformDeliveryResults) {
        platformDeliveryResults.filter { !it.isServiceable }
    }

    Scaffold(
        modifier = modifier.fillMaxSize(),
        topBar = {
            LocationPinBar(
                pinInfo = currentPinInfo,
                isGpsDetecting = isGpsDetecting,
                gpsMessage = gpsMessage,
                themeMode = themeMode,
                onGpsClick = {
                    locationPermissionLauncher.launch(
                        arrayOf(
                            Manifest.permission.ACCESS_FINE_LOCATION,
                            Manifest.permission.ACCESS_COARSE_LOCATION
                        )
                    )
                },
                onPinEditClick = { showPinSheet = true },
                onThemeClick = { showThemeDialog = true },
                onQuickPinSelect = { pin -> viewModel.setPinCode(pin) },
                onDismissGpsMessage = { viewModel.clearGpsMessage() }
            )
        }
    ) { innerPadding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding),
            contentPadding = PaddingValues(bottom = 32.dp)
        ) {
            // Search Input Header
            item {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp, vertical = 8.dp)
                ) {
                    OutlinedTextField(
                        value = searchQuery,
                        onValueChange = { viewModel.onSearchQueryChanged(it) },
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("universal_search_input"),
                        placeholder = { Text("Search soaps, atta, oil, tea, medicines...", fontSize = 13.5.sp) },
                        leadingIcon = {
                            Icon(
                                imageVector = Icons.Default.Search,
                                contentDescription = "Search",
                                tint = MaterialTheme.colorScheme.primary
                            )
                        },
                        trailingIcon = {
                            if (searchQuery.isNotEmpty()) {
                                IconButton(onClick = { viewModel.onSearchQueryChanged("") }) {
                                    Icon(Icons.Default.Clear, contentDescription = "Clear Search")
                                }
                            }
                        },
                        keyboardOptions = KeyboardOptions(imeAction = ImeAction.Search),
                        keyboardActions = KeyboardActions(onSearch = { keyboardController?.hide() }),
                        singleLine = true,
                        shape = RoundedCornerShape(14.dp),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = MaterialTheme.colorScheme.primary,
                            unfocusedBorderColor = MaterialTheme.colorScheme.outlineVariant
                        )
                    )
                }
            }

            // Category Chips Row
            item {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .horizontalScroll(rememberScrollState())
                        .padding(horizontal = 16.dp, vertical = 2.dp),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    ProductRepository.POPULAR_CATEGORIES.forEach { category ->
                        val isSelected = selectedCategory == category
                        FilterChip(
                            selected = isSelected,
                            onClick = { viewModel.onCategorySelected(category) },
                            label = { Text(category, fontSize = 12.sp) },
                            colors = FilterChipDefaults.filterChipColors(
                                selectedContainerColor = MaterialTheme.colorScheme.primaryContainer,
                                selectedLabelColor = MaterialTheme.colorScheme.onPrimaryContainer
                            ),
                            modifier = Modifier.height(32.dp)
                        )
                    }
                }
            }

            // Product Selection Carousel (Quick switcher between items in the category)
            if (filteredProducts.isNotEmpty()) {
                item {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(top = 8.dp, bottom = 4.dp)
                    ) {
                        Text(
                            text = "Matching Products (${filteredProducts.size})",
                            fontSize = 12.sp,
                            fontWeight = FontWeight.SemiBold,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            modifier = Modifier.padding(horizontal = 16.dp, vertical = 2.dp)
                        )

                        LazyRow(
                            contentPadding = PaddingValues(horizontal = 16.dp),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            items(filteredProducts, key = { it.id }) { product ->
                                val isSelected = product.id == selectedProduct.id
                                val borderColor = if (isSelected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.outlineVariant
                                val bgColor = if (isSelected) MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.35f) else MaterialTheme.colorScheme.surface

                                Row(
                                    modifier = Modifier
                                        .clip(RoundedCornerShape(12.dp))
                                        .border(if (isSelected) 1.5.dp else 1.dp, borderColor, RoundedCornerShape(12.dp))
                                        .background(bgColor)
                                        .clickable { viewModel.selectProduct(product) }
                                        .padding(horizontal = 10.dp, vertical = 7.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Text(text = product.iconEmoji, fontSize = 18.sp)
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Column {
                                        Text(
                                            text = product.title,
                                            fontSize = 12.sp,
                                            fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
                                            color = MaterialTheme.colorScheme.onSurface,
                                            maxLines = 1,
                                            overflow = TextOverflow.Ellipsis
                                        )
                                        Text(
                                            text = "${product.brand} • ₹${product.mrp.toInt()}",
                                            fontSize = 11.sp,
                                            color = MaterialTheme.colorScheme.onSurfaceVariant
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            }

            // Stock Alert Banner (Requirement 4: Out of stock / high-savings / fast Kirana replacement)
            item {
                StockAlertBanner(
                    alertInfo = stockAlertInfo,
                    onActionClick = { recommendedPlatform ->
                        if (recommendedPlatform == DeliveryPlatform.LOCAL_KIRANA) {
                            showKiranaSheet = true
                        } else {
                            DeepLinkHelper.openPlatformOrder(context, recommendedPlatform, selectedProduct)
                        }
                    }
                )
            }

            // Filter & Sort Controls (Requirement 3: Deliverable to PIN only, Lowest Price, Fastest Delivery)
            item {
                FilterSortRow(
                    selectedSort = selectedSort,
                    onSortSelected = { viewModel.setSortOption(it) },
                    deliverableOnly = filterDeliverableOnly,
                    onToggleDeliverableOnly = { viewModel.toggleDeliverableOnly() },
                    codOnly = filterCodOnly,
                    onToggleCodOnly = { viewModel.toggleCodOnly() },
                    selectedCategory = filterPlatformCategory,
                    onCategorySelected = { viewModel.setPlatformCategory(it) }
                )
            }

            // Section 1 Header: "Available for Delivery to [PIN Code]" (Requirement 3)
            item {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp, vertical = 8.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            modifier = Modifier
                                .size(24.dp)
                                .clip(CircleShape)
                                .background(Color(0xFFDCFCE7)),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.CheckCircle,
                                contentDescription = null,
                                tint = Color(0xFF15803D),
                                modifier = Modifier.size(15.dp)
                            )
                        }

                        Spacer(modifier = Modifier.width(8.dp))

                        Text(
                            text = "Available for Delivery to ${currentPinInfo.pinCode}",
                            fontSize = 15.sp,
                            fontWeight = FontWeight.ExtraBold,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                    }

                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(12.dp))
                            .background(Color(0xFFDCFCE7))
                            .padding(horizontal = 8.dp, vertical = 2.dp)
                    ) {
                        Text(
                            text = "${serviceableResults.size} Platforms",
                            fontSize = 11.5.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color(0xFF15803D)
                        )
                    }
                }
            }

            // Section 1 List: Serviceable Platform Cards
            if (serviceableResults.isEmpty()) {
                item {
                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 16.dp, vertical = 12.dp),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
                    ) {
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(24.dp),
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            Text(text = "📦", fontSize = 36.sp)
                            Spacer(modifier = Modifier.height(8.dp))
                            Text(
                                text = "No Platforms Match Your Filter",
                                fontSize = 15.sp,
                                fontWeight = FontWeight.Bold
                            )
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = "Try turning off 'COD Only' or switching platform category filter.",
                                fontSize = 12.sp,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                }
            } else {
                items(serviceableResults, key = { "${it.platform.name}_${it.product.id}" }) { result ->
                    ProductResultCard(
                        result = result,
                        onOpenAndOrderClick = {
                            DeepLinkHelper.openPlatformOrder(context, result.platform, result.product)
                        },
                        onWhatsAppKiranaClick = {
                            showKiranaSheet = true
                        },
                        onCallKiranaClick = {
                            val store = nearbyKiranas.firstOrNull()
                            if (store != null) {
                                DeepLinkHelper.callStore(context, store.phone)
                            }
                        }
                    )
                }
            }

            // Section 2: "Unavailable / Not Serviceable at this PIN Code" folded at bottom (Requirement 3)
            if (!filterDeliverableOnly && unserviceableResults.isNotEmpty()) {
                item {
                    UnserviceablePlatformsCard(
                        unserviceableResults = unserviceableResults,
                        pinCode = currentPinInfo.pinCode
                    )
                }
            }
        }
    }

    // Modal Bottom Sheet: PIN Code Selector
    if (showPinSheet) {
        PinCodeSelectorSheet(
            currentPin = currentPinCode,
            recentPins = recentPinCodes,
            sheetState = pinSheetState,
            onDismiss = { showPinSheet = false },
            onPinSelected = { newPin ->
                viewModel.setPinCode(newPin)
                showPinSheet = false
            },
            onResolvePin = { pin ->
                val repo = PinCodeRepository(context)
                repo.resolvePinCode(pin)
            }
        )
    }

    // Modal Bottom Sheet: Local Kirana Direct Order
    if (showKiranaSheet) {
        LocalKiranaSheet(
            stores = nearbyKiranas,
            product = selectedProduct,
            pinInfo = currentPinInfo,
            sheetState = kiranaSheetState,
            onDismiss = { showKiranaSheet = false },
            onSendWhatsApp = { store ->
                DeepLinkHelper.openWhatsAppOrder(
                    context = context,
                    whatsappNumber = store.whatsappNumber,
                    storeName = store.name,
                    product = selectedProduct,
                    pinCode = currentPinInfo.pinCode
                )
                showKiranaSheet = false
            },
            onCallStore = { store ->
                DeepLinkHelper.callStore(context, store.phone)
                showKiranaSheet = false
            }
        )
    }

    // Theme Settings Dialog
    if (showThemeDialog) {
        ThemeSettingsDialog(
            currentThemeMode = themeMode,
            isDynamicColor = dynamicColor,
            onThemeModeSelect = { newMode ->
                viewModel.setThemeMode(newMode)
            },
            onDynamicColorToggle = { enabled ->
                viewModel.setDynamicColor(enabled)
            },
            onDismiss = { showThemeDialog = false }
        )
    }
}
