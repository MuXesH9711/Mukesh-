package com.example.data.repository

import com.example.data.model.DeliveryPlatform
import com.example.data.model.KiranaStore
import com.example.data.model.PinCodeInfo
import com.example.data.model.PinZoneTier
import com.example.data.model.PlatformCategory
import com.example.data.model.PlatformDeliveryResult
import com.example.data.model.ProductItem

object DeliveryService {

    fun evaluateProductDeliverability(
        product: ProductItem,
        pinInfo: PinCodeInfo
    ): List<PlatformDeliveryResult> {
        val results = mutableListOf<PlatformDeliveryResult>()

        // 1. MEESHO (Category 1: PAN-India & Semi-Urban)
        val meeshoPrice = (product.mrp * 0.82).toInt().toDouble()
        val meeshoDays = when (pinInfo.tier) {
            PinZoneTier.METRO -> 2
            PinZoneTier.TIER_2 -> 3
            PinZoneTier.SEMI_URBAN -> 3
            PinZoneTier.RURAL -> 5
        }
        results.add(
            PlatformDeliveryResult(
                platform = DeliveryPlatform.MEESHO,
                product = product,
                isServiceable = true,
                price = meeshoPrice,
                deliveryEtaText = "$meeshoDays-4 Days (Free Shipping)",
                deliveryDays = meeshoDays,
                isCodAvailable = true,
                isFreeDelivery = true,
                deliveryFee = 0.0,
                inStock = true,
                rating = 4.3,
                reviewsCount = 1420
            )
        )

        // 2. AMAZON INDIA (Category 1)
        val amazonPrice = (product.mrp * 0.90).toInt().toDouble()
        val isAmazonRuralServiceable = true
        val amazonDays = when (pinInfo.tier) {
            PinZoneTier.METRO -> 1
            PinZoneTier.TIER_2 -> 2
            PinZoneTier.SEMI_URBAN -> 3
            PinZoneTier.RURAL -> 6
        }
        results.add(
            PlatformDeliveryResult(
                platform = DeliveryPlatform.AMAZON,
                product = product,
                isServiceable = true,
                price = amazonPrice,
                deliveryEtaText = if (pinInfo.tier == PinZoneTier.METRO) "Tomorrow by 11 AM (Prime)" else "$amazonDays Days Standard",
                deliveryDays = amazonDays,
                isCodAvailable = pinInfo.tier != PinZoneTier.RURAL,
                isFreeDelivery = amazonPrice >= 199.0,
                deliveryFee = if (amazonPrice >= 199.0) 0.0 else 40.0,
                inStock = true,
                rating = 4.5,
                reviewsCount = 4890
            )
        )

        // 3. FLIPKART (Category 1)
        val flipkartPrice = (product.mrp * 0.88).toInt().toDouble()
        val flipkartServiceable = pinInfo.tier != PinZoneTier.RURAL
        val flipkartDays = when (pinInfo.tier) {
            PinZoneTier.METRO -> 1
            PinZoneTier.TIER_2 -> 2
            PinZoneTier.SEMI_URBAN -> 4
            PinZoneTier.RURAL -> 7
        }
        results.add(
            PlatformDeliveryResult(
                platform = DeliveryPlatform.FLIPKART,
                product = product,
                isServiceable = flipkartServiceable,
                unserviceableReason = if (!flipkartServiceable) "Seller does not deliver to rural PIN ${pinInfo.pinCode}" else null,
                price = flipkartPrice,
                deliveryEtaText = if (pinInfo.tier == PinZoneTier.METRO) "Delivered in 24 Hours" else "$flipkartDays Days",
                deliveryDays = flipkartDays,
                isCodAvailable = true,
                isFreeDelivery = flipkartPrice >= 150.0,
                deliveryFee = if (flipkartPrice >= 150.0) 0.0 else 40.0,
                inStock = pinInfo.tier != PinZoneTier.SEMI_URBAN || product.id != "prod_aashirvaad_atta", // simulated regional stock check
                rating = 4.4,
                reviewsCount = 3120
            )
        )

        // 4. JIOMART (Category 1)
        val jioPrice = (product.mrp * 0.84).toInt().toDouble()
        val jioDays = when (pinInfo.tier) {
            PinZoneTier.METRO -> 1
            PinZoneTier.TIER_2 -> 2
            PinZoneTier.SEMI_URBAN -> 2
            PinZoneTier.RURAL -> 5
        }
        val jioServiceable = pinInfo.tier != PinZoneTier.RURAL
        results.add(
            PlatformDeliveryResult(
                platform = DeliveryPlatform.JIOMART,
                product = product,
                isServiceable = jioServiceable,
                unserviceableReason = if (!jioServiceable) "JioMart Fulfillment Hub not reached in PIN ${pinInfo.pinCode}" else null,
                price = jioPrice,
                deliveryEtaText = if (pinInfo.tier == PinZoneTier.METRO) "Tomorrow Evening (Free)" else "$jioDays Days Delivery",
                deliveryDays = jioDays,
                isCodAvailable = true,
                isFreeDelivery = true,
                deliveryFee = 0.0,
                inStock = true,
                rating = 4.2,
                reviewsCount = 980
            )
        )

        // 5. SNAPDEAL (Category 1)
        val snapdealPrice = (product.mrp * 0.80).toInt().toDouble()
        val snapdealDays = when (pinInfo.tier) {
            PinZoneTier.METRO -> 3
            PinZoneTier.TIER_2 -> 4
            PinZoneTier.SEMI_URBAN -> 4
            PinZoneTier.RURAL -> 6
        }
        results.add(
            PlatformDeliveryResult(
                platform = DeliveryPlatform.SNAPDEAL,
                product = product,
                isServiceable = true,
                price = snapdealPrice,
                deliveryEtaText = "$snapdealDays-5 Days",
                deliveryDays = snapdealDays,
                isCodAvailable = true,
                isFreeDelivery = true,
                deliveryFee = 0.0,
                inStock = true,
                rating = 3.9,
                reviewsCount = 650
            )
        )

        // 6. TATA 1MG (Category 1 - Specialized in Health & OTC)
        val isHealthCategory = product.category == "Health & OTC" || product.id.contains("soap") || product.id.contains("dettol")
        val tata1mgServiceable = isHealthCategory && pinInfo.tier != PinZoneTier.RURAL
        val tataPrice = (product.mrp * 0.85).toInt().toDouble()
        results.add(
            PlatformDeliveryResult(
                platform = DeliveryPlatform.TATA_1MG,
                product = product,
                isServiceable = tata1mgServiceable,
                unserviceableReason = if (!isHealthCategory) "Tata 1mg delivers pharmacy, personal care & health essentials only" else "Service unavailable in rural PIN ${pinInfo.pinCode}",
                price = tataPrice,
                deliveryEtaText = if (pinInfo.tier == PinZoneTier.METRO) "Same Day Delivery" else "2-3 Days",
                deliveryDays = if (pinInfo.tier == PinZoneTier.METRO) 0 else 2,
                isCodAvailable = true,
                isFreeDelivery = tataPrice >= 500.0,
                deliveryFee = if (tataPrice >= 500.0) 0.0 else 25.0,
                inStock = true,
                rating = 4.6,
                reviewsCount = 840
            )
        )

        // 7. BLINKIT (Category 2: Hyperlocal Quick Commerce)
        val blinkitServiceable = pinInfo.tier == PinZoneTier.METRO
        results.add(
            PlatformDeliveryResult(
                platform = DeliveryPlatform.BLINKIT,
                product = product,
                isServiceable = blinkitServiceable,
                unserviceableReason = if (!blinkitServiceable) "Not Serviceable: Blinkit 10-minute dark stores only operate in urban metro clusters. No warehouse within 10 km of PIN ${pinInfo.pinCode}." else null,
                price = product.mrp,
                deliveryEtaText = "12-15 Mins Instant",
                deliveryDays = 0,
                isCodAvailable = true,
                isFreeDelivery = false,
                deliveryFee = 16.0,
                inStock = true,
                rating = 4.7,
                reviewsCount = 5200
            )
        )

        // 8. ZEPTO (Category 2: Hyperlocal Quick Commerce)
        val zeptoServiceable = pinInfo.tier == PinZoneTier.METRO
        results.add(
            PlatformDeliveryResult(
                platform = DeliveryPlatform.ZEPTO,
                product = product,
                isServiceable = zeptoServiceable,
                unserviceableReason = if (!zeptoServiceable) "Not Serviceable: Zepto 10-min instant delivery is not yet expanded to PIN ${pinInfo.pinCode} (Outside active metro zones)." else null,
                price = (product.mrp * 0.96).toInt().toDouble(),
                deliveryEtaText = "10 Mins Superfast",
                deliveryDays = 0,
                isCodAvailable = false,
                isFreeDelivery = false,
                deliveryFee = 25.0,
                inStock = true,
                rating = 4.6,
                reviewsCount = 4300
            )
        )

        // 9. SWIGGY INSTAMART (Category 2: Hyperlocal Quick Commerce)
        val instamartServiceable = pinInfo.tier == PinZoneTier.METRO || (pinInfo.tier == PinZoneTier.TIER_2 && pinInfo.pinCode.startsWith("302")) // e.g. Jaipur
        results.add(
            PlatformDeliveryResult(
                platform = DeliveryPlatform.SWIGGY_INSTAMART,
                product = product,
                isServiceable = instamartServiceable,
                unserviceableReason = if (!instamartServiceable) "Not Serviceable: Swiggy Instamart pod is not operational in PIN ${pinInfo.pinCode}." else null,
                price = (product.mrp * 0.98).toInt().toDouble(),
                deliveryEtaText = "15-25 Mins",
                deliveryDays = 0,
                isCodAvailable = true,
                isFreeDelivery = false,
                deliveryFee = 20.0,
                inStock = true,
                rating = 4.5,
                reviewsCount = 3800
            )
        )

        // 10. ONDC LOCAL GROCERY (Category 2)
        val ondcServiceable = pinInfo.tier == PinZoneTier.METRO || pinInfo.tier == PinZoneTier.TIER_2
        results.add(
            PlatformDeliveryResult(
                platform = DeliveryPlatform.ONDC_GROCERY,
                product = product,
                isServiceable = ondcServiceable,
                unserviceableReason = if (!ondcServiceable) "Not Serviceable: No ONDC enabled grocery sellers active in postal radius of ${pinInfo.pinCode}." else null,
                price = (product.mrp * 0.92).toInt().toDouble(),
                deliveryEtaText = "45-60 Mins (Direct Local Store)",
                deliveryDays = 0,
                isCodAvailable = true,
                isFreeDelivery = true,
                deliveryFee = 0.0,
                inStock = true,
                rating = 4.1,
                reviewsCount = 320
            )
        )

        // 11. LOCAL KIRANA / DIRECT STORE (Category 3: Neighborhood Store)
        val kiranaPrice = (product.mrp * 0.95).toInt().toDouble()
        results.add(
            PlatformDeliveryResult(
                platform = DeliveryPlatform.LOCAL_KIRANA,
                product = product,
                isServiceable = true,
                price = kiranaPrice,
                deliveryEtaText = "20-40 Mins (WhatsApp / Call)",
                deliveryDays = 0,
                isCodAvailable = true,
                isFreeDelivery = true,
                deliveryFee = 0.0,
                inStock = true,
                rating = 4.8,
                reviewsCount = 185
            )
        )

        return results
    }

    /**
     * Finds nearby registered local Kirana stores for the given PIN Code.
     */
    fun getNearbyKiranaStores(pinInfo: PinCodeInfo): List<KiranaStore> {
        val locality = pinInfo.localityName
        return listOf(
            KiranaStore(
                id = "kirana_1",
                name = "Gupta Provision & General Store",
                ownerName = "Ramesh Gupta",
                phone = "+919876543210",
                whatsappNumber = "919876543210",
                address = "Shop 12, Main Market, near Post Office, $locality",
                pinCode = pinInfo.pinCode,
                distanceKm = 0.4,
                rating = 4.8,
                isFreeHomeDelivery = true,
                minOrderAmount = 150,
                deliveryTimeMinutes = 20,
                isOpenNow = true
            ),
            KiranaStore(
                id = "kirana_2",
                name = "Radhe Shyam Super Kirana",
                ownerName = "Radhe Shyam Sharma",
                phone = "+919811223344",
                whatsappNumber = "919811223344",
                address = "Plot 4, Station Road, $locality",
                pinCode = pinInfo.pinCode,
                distanceKm = 0.8,
                rating = 4.7,
                isFreeHomeDelivery = true,
                minOrderAmount = 200,
                deliveryTimeMinutes = 30,
                isOpenNow = true
            ),
            KiranaStore(
                id = "kirana_3",
                name = "Balaji Daily Essentials & Dairy",
                ownerName = "Suresh Patel",
                phone = "+919799887766",
                whatsappNumber = "919799887766",
                address = "Opposite Shiv Mandir, Gandhi Chowk, $locality",
                pinCode = pinInfo.pinCode,
                distanceKm = 1.2,
                rating = 4.6,
                isFreeHomeDelivery = true,
                minOrderAmount = 100,
                deliveryTimeMinutes = 35,
                isOpenNow = true
            )
        )
    }

    data class StockAlertInfo(
        val message: String,
        val recommendedPlatform: DeliveryPlatform,
        val savingsOrSpeedNote: String
    )

    /**
     * Evaluates cross-platform inventory/serviceability:
     * If an item is out of stock on Flipkart/Amazon, or if quick commerce is unavailable,
     * returns a high-priority alert recommendation.
     */
    fun findCrossPlatformStockAlert(
        product: ProductItem,
        pinInfo: PinCodeInfo,
        results: List<PlatformDeliveryResult>
    ): StockAlertInfo? {
        val flipkart = results.firstOrNull { it.platform == DeliveryPlatform.FLIPKART }
        val amazon = results.firstOrNull { it.platform == DeliveryPlatform.AMAZON }
        val meesho = results.firstOrNull { it.platform == DeliveryPlatform.MEESHO }
        val jiomart = results.firstOrNull { it.platform == DeliveryPlatform.JIOMART }
        val blinkit = results.firstOrNull { it.platform == DeliveryPlatform.BLINKIT }

        // Condition 1: Flipkart or Amazon is out of stock or unserviceable
        if (flipkart != null && (!flipkart.inStock || !flipkart.isServiceable)) {
            val rec = if (jiomart?.isServiceable == true) DeliveryPlatform.JIOMART else DeliveryPlatform.MEESHO
            val price = if (rec == DeliveryPlatform.JIOMART) jiomart?.price else meesho?.price
            return StockAlertInfo(
                message = "Out of stock / unserviceable on Flipkart for PIN ${pinInfo.pinCode}!",
                recommendedPlatform = rec,
                savingsOrSpeedNote = "Found in stock on ${rec.platformName} at ₹${price?.toInt()} with Cash on Delivery."
            )
        }

        // Condition 2: Quick commerce unavailable at this non-metro PIN code
        if (pinInfo.tier == PinZoneTier.SEMI_URBAN || pinInfo.tier == PinZoneTier.RURAL) {
            val meeshoPrice = meesho?.price?.toInt() ?: product.mrp.toInt()
            return StockAlertInfo(
                message = "Blinkit & Zepto unserviceable in PIN ${pinInfo.pinCode}",
                recommendedPlatform = DeliveryPlatform.LOCAL_KIRANA,
                savingsOrSpeedNote = "Local Kirana delivers in 25 mins via WhatsApp! Or order on Meesho/JioMart (₹$meeshoPrice)."
            )
        }

        // Condition 3: JioMart or Meesho is much cheaper than Amazon/Flipkart
        if (meesho != null && amazon != null && (amazon.price - meesho.price) >= 25.0) {
            val diff = (amazon.price - meesho.price).toInt()
            return StockAlertInfo(
                message = "Save ₹$diff on Meesho for PIN ${pinInfo.pinCode}!",
                recommendedPlatform = DeliveryPlatform.MEESHO,
                savingsOrSpeedNote = "Meesho has 100% free delivery & COD for this PIN code."
            )
        }

        return null
    }
}
