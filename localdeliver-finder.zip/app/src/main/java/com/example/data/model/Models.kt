package com.example.data.model

import androidx.compose.ui.graphics.Color

enum class PlatformCategory(val displayName: String, val description: String) {
    PAN_INDIA(
        displayName = "PAN-India & Semi-Urban",
        description = "Broadest postal reach, delivers to semi-urban & rural tier-3 PIN codes (2-5 days)"
    ),
    QUICK_COMMERCE(
        displayName = "Hyperlocal & Quick Commerce",
        description = "Ultra-fast dark-store delivery (10-30 mins), restricted to metro & selected urban PIN codes"
    ),
    LOCAL_KIRANA(
        displayName = "Local Kirana & Direct Store",
        description = "Nearby neighborhood grocery shop with immediate WhatsApp & phone ordering"
    )
}

enum class DeliveryPlatform(
    val platformName: String,
    val category: PlatformCategory,
    val brandColor: Color,
    val textColor: Color,
    val appPackage: String?,
    val webSearchUrl: String,
    val codSupported: Boolean,
    val tagLine: String
) {
    MEESHO(
        platformName = "Meesho",
        category = PlatformCategory.PAN_INDIA,
        brandColor = Color(0xFF9B175B),
        textColor = Color.White,
        appPackage = "com.meesho.supply",
        webSearchUrl = "https://www.meesho.com/search?q=",
        codSupported = true,
        tagLine = "Free Delivery • Lowest Price • 28,000+ PIN Codes"
    ),
    AMAZON(
        platformName = "Amazon",
        category = PlatformCategory.PAN_INDIA,
        brandColor = Color(0xFF232F3E),
        textColor = Color(0xFFFF9900),
        appPackage = "in.amazon.mShop.android.shopping",
        webSearchUrl = "https://www.amazon.in/s?k=",
        codSupported = true,
        tagLine = "Prime & Standard Delivery • High Coverage"
    ),
    FLIPKART(
        platformName = "Flipkart",
        category = PlatformCategory.PAN_INDIA,
        brandColor = Color(0xFF2874F0),
        textColor = Color.White,
        appPackage = "com.flipkart.android",
        webSearchUrl = "https://www.flipkart.com/search?q=",
        codSupported = true,
        tagLine = "SuperCoins • Nationwide Fulfilment"
    ),
    JIOMART(
        platformName = "JioMart",
        category = PlatformCategory.PAN_INDIA,
        brandColor = Color(0xFF0078AD),
        textColor = Color.White,
        appPackage = "com.jio.jiomart",
        webSearchUrl = "https://www.jiomart.com/search/",
        codSupported = true,
        tagLine = "Reliance Retail Network • Deep Semi-Urban Hubs"
    ),
    SNAPDEAL(
        platformName = "Snapdeal",
        category = PlatformCategory.PAN_INDIA,
        brandColor = Color(0xFFE40046),
        textColor = Color.White,
        appPackage = "com.snapdeal.main",
        webSearchUrl = "https://www.snapdeal.com/search?keyword=",
        codSupported = true,
        tagLine = "Bharat Value Commerce • Tier 2/3 Friendly"
    ),
    TATA_1MG(
        platformName = "Tata 1mg",
        category = PlatformCategory.PAN_INDIA,
        brandColor = Color(0xFFFF6F61),
        textColor = Color.White,
        appPackage = "com.aranoah.healthkart.plus",
        webSearchUrl = "https://www.1mg.com/search/all?name=",
        codSupported = true,
        tagLine = "Medicines & Daily Wellness Essentials"
    ),
    BLINKIT(
        platformName = "Blinkit",
        category = PlatformCategory.QUICK_COMMERCE,
        brandColor = Color(0xFFF7C325),
        textColor = Color(0xFF1E293B),
        appPackage = "com.grofers.customerapp",
        webSearchUrl = "https://blinkit.com/s/?q=",
        codSupported = true,
        tagLine = "10-15 Min Delivery • Urban Dark Stores Only"
    ),
    ZEPTO(
        platformName = "Zepto",
        category = PlatformCategory.QUICK_COMMERCE,
        brandColor = Color(0xFF530088),
        textColor = Color.White,
        appPackage = "com.zepto.shopping",
        webSearchUrl = "https://www.zeptonow.com/search?q=",
        codSupported = false,
        tagLine = "10 Min Instant Groceries • Metro Hubs Only"
    ),
    SWIGGY_INSTAMART(
        platformName = "Instamart",
        category = PlatformCategory.QUICK_COMMERCE,
        brandColor = Color(0xFFFC8019),
        textColor = Color.White,
        appPackage = "in.swiggy.android",
        webSearchUrl = "https://www.swiggy.com/instamart/search?query=",
        codSupported = true,
        tagLine = "Swiggy Fast Grocery • Metro & Tier 1 Cities"
    ),
    ONDC_GROCERY(
        platformName = "ONDC Local",
        category = PlatformCategory.QUICK_COMMERCE,
        brandColor = Color(0xFF0F766E),
        textColor = Color.White,
        appPackage = null,
        webSearchUrl = "https://ondc.org",
        codSupported = true,
        tagLine = "Open Network for Digital Commerce Grocers"
    ),
    LOCAL_KIRANA(
        platformName = "Kirana Direct",
        category = PlatformCategory.LOCAL_KIRANA,
        brandColor = Color(0xFF15803D),
        textColor = Color.White,
        appPackage = "com.whatsapp",
        webSearchUrl = "",
        codSupported = true,
        tagLine = "Nearby Shop • Instant WhatsApp & Call Order"
    )
}

enum class PinZoneTier(val label: String, val description: String) {
    METRO("Metro / Urban", "All Quick Commerce & PAN-India platforms active"),
    TIER_2("Tier 2 / Sub-Urban", "PAN-India active, selective quick commerce"),
    SEMI_URBAN("Semi-Urban / Tier 3", "PAN-India active (2-4 days), Quick commerce unserviceable"),
    RURAL("Rural / Remote", "Selected PAN-India (India Post/Meesho), Quick commerce unserviceable")
}

data class PinCodeInfo(
    val pinCode: String,
    val localityName: String,
    val district: String,
    val state: String,
    val tier: PinZoneTier,
    val latitude: Double? = null,
    val longitude: Double? = null
)

data class ProductItem(
    val id: String,
    val title: String,
    val category: String,
    val standardQuantity: String,
    val mrp: Double,
    val iconEmoji: String,
    val description: String,
    val brand: String
)

data class PlatformDeliveryResult(
    val platform: DeliveryPlatform,
    val product: ProductItem,
    val isServiceable: Boolean,
    val unserviceableReason: String? = null,
    val price: Double,
    val deliveryEtaText: String,
    val deliveryDays: Int, // 0 for quick commerce (same hour), 1 for tomorrow, 2..7 for days
    val isCodAvailable: Boolean,
    val isFreeDelivery: Boolean,
    val deliveryFee: Double = 0.0,
    val inStock: Boolean = true,
    val rating: Double = 4.3,
    val reviewsCount: Int = 120
)

data class KiranaStore(
    val id: String,
    val name: String,
    val ownerName: String,
    val phone: String,
    val whatsappNumber: String,
    val address: String,
    val pinCode: String,
    val distanceKm: Double,
    val rating: Double,
    val isFreeHomeDelivery: Boolean,
    val minOrderAmount: Int,
    val deliveryTimeMinutes: Int,
    val isOpenNow: Boolean
)

enum class SortOption(val title: String) {
    FASTEST_DELIVERY("Fastest Delivery"),
    LOWEST_PRICE("Lowest Price"),
    PLATFORM_NAME("Platform (A-Z)")
}
