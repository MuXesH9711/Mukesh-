package com.example.data.repository

import com.example.data.model.ProductItem

object ProductRepository {

    val PRODUCTS = listOf(
        // Bath & Soaps
        ProductItem(
            id = "prod_dettol_soap",
            title = "Dettol Original Germ Protection Bathing Soap (Pack of 4)",
            category = "Personal Care",
            standardQuantity = "125g x 4",
            mrp = 220.0,
            iconEmoji = "🧼",
            description = "Antibacterial bathing bar with trusted Dettol fragrance and 99.9% germ protection.",
            brand = "Dettol"
        ),
        ProductItem(
            id = "prod_lifebuoy_soap",
            title = "Lifebuoy Total 10 Immunity Boosting Bathing Soap Bar",
            category = "Personal Care",
            standardQuantity = "125g x 4",
            mrp = 180.0,
            iconEmoji = "🧼",
            description = "Silver Shield formula provides 100% stronger germ protection.",
            brand = "Lifebuoy"
        ),
        ProductItem(
            id = "prod_dove_soap",
            title = "Dove Cream Beauty Bathing Soap Bar (Pack of 3)",
            category = "Personal Care",
            standardQuantity = "100g x 3",
            mrp = 210.0,
            iconEmoji = "🫧",
            description = "Enriched with 1/4th moisturizing cream for soft, smooth and glowing skin.",
            brand = "Dove"
        ),
        ProductItem(
            id = "prod_godrej_no1",
            title = "Godrej No. 1 Sandal & Turmeric Soap",
            category = "Personal Care",
            standardQuantity = "100g x 5",
            mrp = 145.0,
            iconEmoji = "🧼",
            description = "Natural oils and Grade 1 soap with soothing sandalwood aroma.",
            brand = "Godrej No. 1"
        ),

        // Staples & Groceries
        ProductItem(
            id = "prod_aashirvaad_atta",
            title = "Aashirvaad Shudh Chakki Atta 100% Whole Wheat",
            category = "Groceries & Staples",
            standardQuantity = "5 kg",
            mrp = 265.0,
            iconEmoji = "🌾",
            description = "4-step advantage process ensures 100% pure whole wheat rotis stay soft longer.",
            brand = "Aashirvaad"
        ),
        ProductItem(
            id = "prod_fortune_oil",
            title = "Fortune Sunlite Refined Sunflower Oil Pouch",
            category = "Groceries & Staples",
            standardQuantity = "1 Litre",
            mrp = 145.0,
            iconEmoji = "🌻",
            description = "Rich in Vitamin E and Omega-6, light and healthy cooking oil.",
            brand = "Fortune"
        ),
        ProductItem(
            id = "prod_tata_salt",
            title = "Tata Salt Vacuum Evaporated Iodised Salt",
            category = "Groceries & Staples",
            standardQuantity = "1 kg",
            mrp = 28.0,
            iconEmoji = "🧂",
            description = "Desh ka Namak with adequate iodine for mental and physical development.",
            brand = "Tata Salt"
        ),
        ProductItem(
            id = "prod_india_gate_rice",
            title = "India Gate Basmati Rice Feast Rozzana",
            category = "Groceries & Staples",
            standardQuantity = "1 kg",
            mrp = 110.0,
            iconEmoji = "🍚",
            description = "Fluffy long grain basmati rice ideal for everyday biryani, pulao, and steamed rice.",
            brand = "India Gate"
        ),
        ProductItem(
            id = "prod_tata_sampann_dal",
            title = "Tata Sampann Unpolished Toor Dal (Arhar Dal)",
            category = "Groceries & Staples",
            standardQuantity = "1 kg",
            mrp = 195.0,
            iconEmoji = "🥣",
            description = "Unpolished dal retaining natural protein and wholesome nutrients.",
            brand = "Tata Sampann"
        ),
        ProductItem(
            id = "prod_madhur_sugar",
            title = "Madhur Pure & Hygienic Sulphurless Sugar",
            category = "Groceries & Staples",
            standardQuantity = "1 kg",
            mrp = 60.0,
            iconEmoji = "🍬",
            description = "100% sulphur-free crystal clear sugar processed untouched by hand.",
            brand = "Madhur"
        ),

        // Quick Snacks & Dairy
        ProductItem(
            id = "prod_maggi_noodles",
            title = "Maggi 2-Minute Masala Instant Noodles",
            category = "Snacks & Beverages",
            standardQuantity = "Pack of 4 (280g)",
            mrp = 56.0,
            iconEmoji = "🍜",
            description = "India's favorite instant noodles with authentic roasted spices blend.",
            brand = "Maggi"
        ),
        ProductItem(
            id = "prod_amul_butter",
            title = "Amul Pasteurised Butter",
            category = "Snacks & Beverages",
            standardQuantity = "100 g",
            mrp = 60.0,
            iconEmoji = "🧈",
            description = "Utterly butterly delicious fresh table butter made from pure milk.",
            brand = "Amul"
        ),
        ProductItem(
            id = "prod_tata_tea_gold",
            title = "Tata Tea Gold Leaf Black Tea",
            category = "Snacks & Beverages",
            standardQuantity = "500 g",
            mrp = 340.0,
            iconEmoji = "☕",
            description = "Fine blend of gently rolled aromatic long leaves with Assam CTC tea.",
            brand = "Tata Tea"
        ),
        ProductItem(
            id = "prod_parle_g",
            title = "Parle-G Original Gluco Biscuits Value Pack",
            category = "Snacks & Beverages",
            standardQuantity = "800 g",
            mrp = 80.0,
            iconEmoji = "🍪",
            description = "Goodness of wheat and milk, the world's highest selling biscuit.",
            brand = "Parle-G"
        ),
        ProductItem(
            id = "prod_nescafe_coffee",
            title = "Nescafe Classic 100% Pure Instant Coffee Jar",
            category = "Snacks & Beverages",
            standardQuantity = "50 g",
            mrp = 185.0,
            iconEmoji = "☕",
            description = "Rich aroma and unmistakable roast flavour made from quality Robusta beans.",
            brand = "Nescafe"
        ),

        // Personal Care & Hygiene
        ProductItem(
            id = "prod_colgate_paste",
            title = "Colgate Strong Teeth Dental Cream Toothpaste",
            category = "Personal Care",
            standardQuantity = "200 g Saver Pack",
            mrp = 130.0,
            iconEmoji = "🪥",
            description = "Calcium boost formula restores natural calcium to strengthen tooth enamel.",
            brand = "Colgate"
        ),
        ProductItem(
            id = "prod_head_shoulders",
            title = "Head & Shoulders Anti-Dandruff Cool Menthol Shampoo",
            category = "Personal Care",
            standardQuantity = "180 ml",
            mrp = 190.0,
            iconEmoji = "🧴",
            description = "Cleanses scalp and removes dandruff with cooling natural menthol feel.",
            brand = "Head & Shoulders"
        ),
        ProductItem(
            id = "prod_parachute_oil",
            title = "Parachute 100% Pure Coconut Hair Oil",
            category = "Personal Care",
            standardQuantity = "200 ml",
            mrp = 95.0,
            iconEmoji = "🥥",
            description = "5-stage purification process ensures deep conditioning and hair nourishment.",
            brand = "Parachute"
        ),

        // Health & OTC Essentials
        ProductItem(
            id = "prod_dolo_650",
            title = "Dolo 650mg Paracetamol Tablets",
            category = "Health & OTC",
            standardQuantity = "Strip of 15 Tablets",
            mrp = 34.0,
            iconEmoji = "💊",
            description = "Fast relief from mild to moderate fever, headaches, body pain.",
            brand = "Micro Labs"
        ),
        ProductItem(
            id = "prod_vicks_vaporub",
            title = "Vicks VapoRub Balm for Cold Relief",
            category = "Health & OTC",
            standardQuantity = "25 ml",
            mrp = 85.0,
            iconEmoji = "🌿",
            description = "Relieves blocked nose, cough, and muscular aches caused by cold.",
            brand = "Vicks"
        ),
        ProductItem(
            id = "prod_dabur_chyawanprash",
            title = "Dabur Chyawanprash 2X Immunity Booster",
            category = "Health & OTC",
            standardQuantity = "500 g",
            mrp = 225.0,
            iconEmoji = "🍯",
            description = "Ayurvedic herbal jam with goodness of Amla and 40+ natural herbs.",
            brand = "Dabur"
        ),

        // Household & Cleaning
        ProductItem(
            id = "prod_surf_excel",
            title = "Surf Excel Quick Wash Detergent Powder",
            category = "Household Cleaning",
            standardQuantity = "1 kg",
            mrp = 155.0,
            iconEmoji = "🧺",
            description = "Super fast dirt removal in the washing machine with superior fragrance.",
            brand = "Surf Excel"
        ),
        ProductItem(
            id = "prod_vim_bar",
            title = "Vim Dishwash Bar with Pure Lemon Power",
            category = "Household Cleaning",
            standardQuantity = "300 g x 3",
            mrp = 65.0,
            iconEmoji = "🍋",
            description = "100 lemons power cuts through burnt-on tough oil stains effortlessly.",
            brand = "Vim"
        ),
        ProductItem(
            id = "prod_lizol",
            title = "Lizol Disinfectant Surface Floor Cleaner Citrus",
            category = "Household Cleaning",
            standardQuantity = "500 ml",
            mrp = 115.0,
            iconEmoji = "✨",
            description = "Kills 99.9% germs and leaves floors spotless with fresh lemon fragrance.",
            brand = "Lizol"
        )
    )

    val POPULAR_CATEGORIES = listOf(
        "All Essentials",
        "Personal Care",
        "Groceries & Staples",
        "Snacks & Beverages",
        "Health & OTC",
        "Household Cleaning"
    )

    fun searchProducts(query: String, category: String?): List<ProductItem> {
        val q = query.trim().lowercase()
        return PRODUCTS.filter { product ->
            val matchesCategory = category == null || category == "All Essentials" || product.category.equals(category, ignoreCase = true)
            val matchesQuery = q.isEmpty() ||
                    product.title.lowercase().contains(q) ||
                    product.brand.lowercase().contains(q) ||
                    product.description.lowercase().contains(q) ||
                    product.category.lowercase().contains(q)
            matchesCategory && matchesQuery
        }
    }
}
