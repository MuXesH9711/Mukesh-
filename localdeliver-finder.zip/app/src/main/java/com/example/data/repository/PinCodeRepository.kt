package com.example.data.repository

import android.content.Context
import android.content.SharedPreferences
import com.example.data.model.PinCodeInfo
import com.example.data.model.PinZoneTier
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

class PinCodeRepository(private val context: Context) {

    private val prefs: SharedPreferences =
        context.getSharedPreferences("localdeliver_prefs", Context.MODE_PRIVATE)

    private val _recentPinCodes = MutableStateFlow<List<String>>(emptyList())
    val recentPinCodes: StateFlow<List<String>> = _recentPinCodes.asStateFlow()

    init {
        loadRecentPinCodes()
    }

    private fun loadRecentPinCodes() {
        val saved = prefs.getString("recent_pins", null)
        val list = if (saved.isNullOrBlank()) {
            listOf("110001", "560001", "841301", "302001", "281001", "400001")
        } else {
            saved.split(",").filter { it.length == 6 }
        }
        _recentPinCodes.value = list
    }

    fun saveRecentPinCode(pin: String) {
        if (pin.length != 6) return
        val current = _recentPinCodes.value.toMutableList()
        current.remove(pin)
        current.add(0, pin)
        val updated = current.take(8)
        _recentPinCodes.value = updated
        prefs.edit().putString("recent_pins", updated.joinToString(",")).apply()
    }

    /**
     * Resolves PIN code details. If found in curated Indian dictionary, returns exact city/tier.
     * Otherwise uses official Indian Postal Circle rules for dynamic detection.
     */
    fun resolvePinCode(pin: String): PinCodeInfo {
        val trimmed = pin.trim()
        val predefined = CURATED_PIN_CODES[trimmed]
        if (predefined != null) {
            return predefined
        }

        // Dynamic Postal Circle Fallback for any 6-digit Indian PIN Code
        return deduceFromPostalCircle(trimmed)
    }

    private fun deduceFromPostalCircle(pin: String): PinCodeInfo {
        if (pin.length < 2) {
            return PinCodeInfo(
                pinCode = pin,
                localityName = "Custom Location",
                district = "India",
                state = "India",
                tier = PinZoneTier.SEMI_URBAN
            )
        }

        val firstDigit = pin[0]
        val firstTwo = pin.take(2).toIntOrNull() ?: 11

        val (state, tierGuess) = when (firstDigit) {
            '1' -> when (firstTwo) {
                11 -> "Delhi" to PinZoneTier.METRO
                12, 13 -> "Haryana" to PinZoneTier.TIER_2
                14, 15, 16 -> "Punjab & Chandigarh" to PinZoneTier.TIER_2
                17 -> "Himachal Pradesh" to PinZoneTier.SEMI_URBAN
                18, 19 -> "Jammu & Kashmir" to PinZoneTier.RURAL
                else -> "North Zone" to PinZoneTier.SEMI_URBAN
            }
            '2' -> when (firstTwo) {
                in 20..28 -> "Uttar Pradesh" to PinZoneTier.SEMI_URBAN
                24 -> "Uttarakhand" to PinZoneTier.SEMI_URBAN
                else -> "Uttar Pradesh" to PinZoneTier.SEMI_URBAN
            }
            '3' -> when (firstTwo) {
                in 30..34 -> "Rajasthan" to PinZoneTier.TIER_2
                in 36..39 -> "Gujarat" to PinZoneTier.TIER_2
                else -> "Western Zone" to PinZoneTier.SEMI_URBAN
            }
            '4' -> when (firstTwo) {
                40 -> "Mumbai, Maharashtra" to PinZoneTier.METRO
                41, 42 -> "Pune & Nashik, Maharashtra" to PinZoneTier.TIER_2
                in 43..44 -> "Vidarbha / Marathwada, Maharashtra" to PinZoneTier.SEMI_URBAN
                45, 46 -> "Madhya Pradesh (Indore/Bhopal)" to PinZoneTier.TIER_2
                in 47..48 -> "Madhya Pradesh (Semi-urban)" to PinZoneTier.SEMI_URBAN
                49 -> "Chhattisgarh" to PinZoneTier.SEMI_URBAN
                else -> "Central Zone" to PinZoneTier.SEMI_URBAN
            }
            '5' -> when (firstTwo) {
                50 -> "Hyderabad, Telangana" to PinZoneTier.METRO
                in 51..53 -> "Andhra Pradesh" to PinZoneTier.TIER_2
                56 -> "Bengaluru, Karnataka" to PinZoneTier.METRO
                in 57..59 -> "Karnataka" to PinZoneTier.SEMI_URBAN
                else -> "South Zone" to PinZoneTier.SEMI_URBAN
            }
            '6' -> when (firstTwo) {
                60 -> "Chennai, Tamil Nadu" to PinZoneTier.METRO
                in 61..64 -> "Tamil Nadu" to PinZoneTier.TIER_2
                in 67..69 -> "Kerala" to PinZoneTier.TIER_2
                else -> "South Zone" to PinZoneTier.SEMI_URBAN
            }
            '7' -> when (firstTwo) {
                70 -> "Kolkata, West Bengal" to PinZoneTier.METRO
                in 71..74 -> "West Bengal" to PinZoneTier.SEMI_URBAN
                in 75..77 -> "Odisha" to PinZoneTier.SEMI_URBAN
                78 -> "Assam" to PinZoneTier.SEMI_URBAN
                79 -> "North Eastern Region" to PinZoneTier.RURAL
                else -> "Eastern Zone" to PinZoneTier.SEMI_URBAN
            }
            '8' -> when (firstTwo) {
                80 -> "Patna, Bihar" to PinZoneTier.TIER_2
                in 81..85 -> "Bihar & Jharkhand (Semi-Urban)" to PinZoneTier.SEMI_URBAN
                else -> "Bihar / Jharkhand" to PinZoneTier.SEMI_URBAN
            }
            else -> "India (Regional)" to PinZoneTier.SEMI_URBAN
        }

        return PinCodeInfo(
            pinCode = pin,
            localityName = "Area $pin",
            district = state,
            state = state,
            tier = tierGuess
        )
    }

    companion object {
        val CURATED_PIN_CODES = mapOf(
            // Metros
            "110001" to PinCodeInfo("110001", "Connaught Place", "New Delhi", "Delhi", PinZoneTier.METRO, 28.6315, 77.2167),
            "110016" to PinCodeInfo("110016", "Hauz Khas", "South Delhi", "Delhi", PinZoneTier.METRO, 28.5494, 77.2001),
            "560001" to PinCodeInfo("560001", "MG Road / Brigade", "Bengaluru Urban", "Karnataka", PinZoneTier.METRO, 12.9716, 77.5946),
            "560034" to PinCodeInfo("560034", "Koramangala", "Bengaluru Urban", "Karnataka", PinZoneTier.METRO, 12.9352, 77.6245),
            "400001" to PinCodeInfo("400001", "Fort / Colaba", "Mumbai City", "Maharashtra", PinZoneTier.METRO, 18.9322, 72.8350),
            "400050" to PinCodeInfo("400050", "Bandra West", "Mumbai Suburban", "Maharashtra", PinZoneTier.METRO, 19.0596, 72.8295),
            "700001" to PinCodeInfo("700001", "BBD Bagh / Central", "Kolkata", "West Bengal", PinZoneTier.METRO, 22.5726, 88.3639),
            "500001" to PinCodeInfo("500001", "Abids / Koti", "Hyderabad", "Telangana", PinZoneTier.METRO, 17.3850, 78.4867),
            "600001" to PinCodeInfo("600001", "George Town", "Chennai", "Tamil Nadu", PinZoneTier.METRO, 13.0827, 80.2707),

            // Tier 2 / Sub-Urban
            "302001" to PinCodeInfo("302001", "MI Road / C-Scheme", "Jaipur", "Rajasthan", PinZoneTier.TIER_2, 26.9124, 75.7873),
            "226001" to PinCodeInfo("226001", "Hazratganj", "Lucknow", "Uttar Pradesh", PinZoneTier.TIER_2, 26.8467, 80.9462),
            "452001" to PinCodeInfo("452001", "Rajwada / Central", "Indore", "Madhya Pradesh", PinZoneTier.TIER_2, 22.7196, 75.8577),
            "411001" to PinCodeInfo("411001", "Shivaji Nagar / Camp", "Pune", "Maharashtra", PinZoneTier.TIER_2, 18.5204, 73.8567),
            "141001" to PinCodeInfo("141001", "Civil Lines", "Ludhiana", "Punjab", PinZoneTier.TIER_2, 30.9010, 75.8573),
            "800001" to PinCodeInfo("800001", "Fraser Road / Gandhi Maidan", "Patna", "Bihar", PinZoneTier.TIER_2, 25.5941, 85.1376),
            "380001" to PinCodeInfo("380001", "Lal Darwaja / Ashram Rd", "Ahmedabad", "Gujarat", PinZoneTier.TIER_2, 23.0225, 72.5714),

            // Semi-Urban / Tier 3
            "841301" to PinCodeInfo("841301", "Chhapra Bazar", "Saran", "Bihar", PinZoneTier.SEMI_URBAN, 25.7811, 84.7466),
            "281001" to PinCodeInfo("281001", "Chhatta Bazar", "Mathura", "Uttar Pradesh", PinZoneTier.SEMI_URBAN, 27.4924, 77.6737),
            "360001" to PinCodeInfo("360001", "Dharmendrasinhji Rd", "Rajkot", "Gujarat", PinZoneTier.SEMI_URBAN, 22.3039, 70.8022),
            "670001" to PinCodeInfo("670001", "Thavakkara", "Kannur", "Kerala", PinZoneTier.SEMI_URBAN, 11.8745, 75.3704),
            "590001" to PinCodeInfo("590001", "Khade Bazar", "Belagavi", "Karnataka", PinZoneTier.SEMI_URBAN, 15.8497, 74.4977),
            "273001" to PinCodeInfo("273001", "Golghar", "Gorakhpur", "Uttar Pradesh", PinZoneTier.SEMI_URBAN, 26.7606, 83.3732),

            // Rural / Remote
            "194101" to PinCodeInfo("194101", "Main Market Leh", "Leh Ladakh", "Ladakh", PinZoneTier.RURAL, 34.1526, 77.5771),
            "795001" to PinCodeInfo("795001", "Paona Bazar", "Imphal West", "Manipur", PinZoneTier.RURAL, 24.8170, 93.9368),
            "246174" to PinCodeInfo("246174", "Pauri Town", "Pauri Garhwal", "Uttarakhand", PinZoneTier.RURAL, 30.1500, 78.7800)
        )

        val DEFAULT_PIN = "110001"
    }
}
