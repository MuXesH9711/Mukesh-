package com.example.util

import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.widget.Toast
import com.example.data.model.DeliveryPlatform
import com.example.data.model.ProductItem
import java.net.URLEncoder

object DeepLinkHelper {

    fun openPlatformOrder(
        context: Context,
        platform: DeliveryPlatform,
        product: ProductItem
    ) {
        val query = "${product.brand} ${product.title}"
        val encodedQuery = try {
            URLEncoder.encode(query, "UTF-8")
        } catch (e: Exception) {
            query.replace(" ", "+")
        }

        // Handle Kirana
        if (platform == DeliveryPlatform.LOCAL_KIRANA) {
            Toast.makeText(context, "Opening Local Kirana Quick Order...", Toast.LENGTH_SHORT).show()
            return
        }

        val packageManager = context.packageManager
        val appPackage = platform.appPackage

        // 1. Try launching native installed app
        if (!appPackage.isNullOrBlank()) {
            val isAppInstalled = try {
                packageManager.getPackageInfo(appPackage, PackageManager.GET_ACTIVITIES)
                true
            } catch (e: Exception) {
                false
            }

            if (isAppInstalled) {
                val launchIntent = packageManager.getLaunchIntentForPackage(appPackage)
                if (launchIntent != null) {
                    launchIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    try {
                        context.startActivity(launchIntent)
                        Toast.makeText(context, "Opening ${platform.platformName} App...", Toast.LENGTH_SHORT).show()
                        return
                    } catch (e: Exception) {
                        // fallback to web
                    }
                }
            }
        }

        // 2. Fallback to Platform Web Search URL
        val targetUrl = when (platform) {
            DeliveryPlatform.MEESHO -> "https://www.meesho.com/search?q=$encodedQuery"
            DeliveryPlatform.AMAZON -> "https://www.amazon.in/s?k=$encodedQuery"
            DeliveryPlatform.FLIPKART -> "https://www.flipkart.com/search?q=$encodedQuery"
            DeliveryPlatform.JIOMART -> "https://www.jiomart.com/search/$encodedQuery"
            DeliveryPlatform.SNAPDEAL -> "https://www.snapdeal.com/search?keyword=$encodedQuery"
            DeliveryPlatform.TATA_1MG -> "https://www.1mg.com/search/all?name=$encodedQuery"
            DeliveryPlatform.BLINKIT -> "https://blinkit.com/s/?q=$encodedQuery"
            DeliveryPlatform.ZEPTO -> "https://www.zeptonow.com/search?q=$encodedQuery"
            DeliveryPlatform.SWIGGY_INSTAMART -> "https://www.swiggy.com/instamart/search?query=$encodedQuery"
            DeliveryPlatform.ONDC_GROCERY -> "https://buyer.ondc.org/search?q=$encodedQuery"
            DeliveryPlatform.LOCAL_KIRANA -> "https://wa.me/"
        }

        try {
            val browserIntent = Intent(Intent.ACTION_VIEW, Uri.parse(targetUrl))
            browserIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            context.startActivity(browserIntent)
            Toast.makeText(context, "Opening ${platform.platformName} Search...", Toast.LENGTH_SHORT).show()
        } catch (e: Exception) {
            Toast.makeText(context, "No browser found to open link.", Toast.LENGTH_SHORT).show()
        }
    }

    fun openWhatsAppOrder(
        context: Context,
        whatsappNumber: String,
        storeName: String,
        product: ProductItem,
        pinCode: String
    ) {
        val cleanNumber = whatsappNumber.replace("+", "").replace(" ", "").replace("-", "")
        val rawMessage = "Namaste $storeName,\n\nI want to order via LocalDeliver:\n• ${product.title} (${product.standardQuantity})\n\nDelivery Address PIN: $pinCode\nPlease confirm stock availability and estimated delivery time. Thank you!"

        val encodedMsg = try {
            URLEncoder.encode(rawMessage, "UTF-8")
        } catch (e: Exception) {
            rawMessage.replace(" ", "%20")
        }

        val uri = Uri.parse("https://wa.me/$cleanNumber?text=$encodedMsg")
        val intent = Intent(Intent.ACTION_VIEW, uri)
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)

        try {
            context.startActivity(intent)
        } catch (e: Exception) {
            Toast.makeText(context, "WhatsApp is not installed. Dialing store...", Toast.LENGTH_SHORT).show()
            callStore(context, whatsappNumber)
        }
    }

    fun callStore(context: Context, phoneNumber: String) {
        val intent = Intent(Intent.ACTION_DIAL, Uri.parse("tel:$phoneNumber"))
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        try {
            context.startActivity(intent)
        } catch (e: Exception) {
            Toast.makeText(context, "Cannot open phone dialer.", Toast.LENGTH_SHORT).show()
        }
    }
}
